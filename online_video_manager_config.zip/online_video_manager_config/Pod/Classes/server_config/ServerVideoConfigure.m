//
// Created by djzhang on 1/1/15.
// Copyright (c) 2015 djzhang. All rights reserved.
//

#import "ServerVideoConfigure.h"


@implementation ServerVideoConfigure {

}

+ (NSArray *)youtubeArray {
   return @[
//    @"/Volumes/macshare/MacPE/youtubes",
//    @"/Volumes/AppCache/TubeDownload",
   ];
}


+ (NSArray *)lyndaArray {
   return @[
    @"/Volumes/macshare/MacPE/Lynda.com",
   ];
}


@end
