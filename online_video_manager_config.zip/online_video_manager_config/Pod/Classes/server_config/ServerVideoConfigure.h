//
// Created by djzhang on 1/1/15.
// Copyright (c) 2015 djzhang. All rights reserved.
//


static NSString * const htdocs = @"/Volumes";

static NSString * const appProfile = @".AOnlineTutorial";
static NSString * const appCacheDirectory = @".cache";

//#define needGenerateThumbnail NO
#define needGenerateThumbnail YES


@interface ServerVideoConfigure : NSObject

+ (NSArray *)youtubeArray;
+ (NSArray *)lyndaArray;

@end

