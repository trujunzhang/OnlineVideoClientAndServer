# online_video_manager_config

[![CI Status](http://img.shields.io/travis/wanghaogithub720/online_video_manager_config.svg?style=flat)](https://travis-ci.org/wanghaogithub720/online_video_manager_config)
[![Version](https://img.shields.io/cocoapods/v/online_video_manager_config.svg?style=flat)](http://cocoadocs.org/docsets/online_video_manager_config)
[![License](https://img.shields.io/cocoapods/l/online_video_manager_config.svg?style=flat)](http://cocoadocs.org/docsets/online_video_manager_config)
[![Platform](https://img.shields.io/cocoapods/p/online_video_manager_config.svg?style=flat)](http://cocoadocs.org/docsets/online_video_manager_config)

## Usage

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

online_video_manager_config is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

    pod "online_video_manager_config"

## Author

wanghaogithub720, wanghaomspace@gmail.com

## License

online_video_manager_config is available under the MIT license. See the LICENSE file for more info.

